##########################################################
###   ENDOCRANIAL DEVELOPMENT IN NON-AVIAN DINOSAURS   ###
###   REVEALS AN ONTOGENETIC BRAIN TRAJECTORY          ###
###   DISTINCT FROM EXTANT ARCHOSAURS                  ###
##########################################################

### AUTHORS:
### L KING, Z QI, DL DUFEAU, S KAWABE, L WITMER, C ZHOU, EJ RAYFIELD, MJ BENTON, A WATANABE

### << LIBRARIES >> ###
library(abind); library(ape); library(geiger); library(geomorph); library(geoscale); library(ggplot2); library(Morpho); library(paleomorph); library(phytools); library(plotrix); library(qgraph); library(RColorBrewer); library(Rvcg)

### << INITIALIZATION >> ###
setwd("/Users/watanabe/Library/CloudStorage/OneDrive-NewYorkInstituteofTechnology/Projects/TheropodBrainEvolutionPLUS/Manuscript/NatureComm/R2/SuppData/")
left.lm <- c(1:54,109:137,168:170,173:175,178:180,183:185,188:190,193:195,198:200,203:205,208:210,213:215,218:220,222:224)

### << COORDINATE & SIZE DATA >> ###
{  
  shape.data <- read.csv("./SuppData1.csv", header=TRUE, row.names=1)  # read Procrustes-aligned data
  shape.data <- arrayspecs(shape.data, ncol(shape.data)/3, 3)
  labels <- dimnames(shape.data)[[3]]
  genus.labels <- gsub("_[A-z,1-9]+","", labels)
  cs <- read.csv("./SuppData2.csv", header=FALSE, row.names=1)  # read centroid size
  log.cs <- log(cs)
}

### << Phylogenetic Tree >> ###
phy <- read.tree("./SuppData3.tre")
swap.label <- which(phy$tip.label %in% c("Alligator_mississippiensis_Adult_endocast","Gallus_gallus","Gallirallus_philippensis","Psittacosaurus_lujiatunensis", "Lambeosaurus_sp", "Corythosaurus_sp","Hypacrosaurus_altispinus","Tyrannosaurus_rex","Gorgosaurus_libratus"))
phy$tip.label[swap.label] <- c("Alligator_Adult_endocast","Chicken_Adult_2_endocast","Gallirallus_phillippensis","Psittacosaurus_lujiatunensis_IVPP12617","Lambeosaurus_juv_ROM758_endocast","Corythosaurus_CMN34821","Hypacrosaurus_ROM702_endocast","T.rex_FMNH_PR2081_endocast","Gorgosaurus_ROM1247_endocast")

### << TAXONOMIC ASSIGNMENT >> ###
{
  dinos <- c(2,42,44,45,55,58:61,62,63,64,71,72,78:81,85)  # for taxa with multiple specimens, largest CS extracted
  aves <- c(1,17:26,41,43,46:54,56,57,65:70,73:77,82:84)
  neornith <- c(1,17,18,20:26,41,43,46:54,56,57,65:70,73:77,82:84)
  gator.dev <- 3:16
  chick.dev <- 27:40
  dino.dev <- c(60,62,64,80,85)
  ornithischia.dev <- c(62,64) 
  saurischia.dev <- c(60,80,85)
  dev <- c(gator.dev, chick.dev, dino.dev)
  no.dev <- c(1:3,17:26,40:44,46:59,61,63,65:70,73:77,81:84)
  ornithischian <- c(44,45,58,61,62,64,71,72)
  saurischian <- c(2,42,55,59,60,63,78:81,85)
  psittaco <- c(61,62,71,72)

  shape.dinos <- shape.data[,,dinos]
  shape.aves <- shape.data[,,aves]
  shape.neornith <- shape.data[,,neornith]
  shape.gator <- shape.data[,,gator.dev]
  shape.chick <- shape.data[,,chick.dev]
  shape.dinodev <- shape.data[,,dino.dev]
  shape.nodev <- shape.data[,,no.dev]
 
  cs.dinos <- cs[dinos,]
  cs.aves <- cs[aves,]
  cs.neornith <- cs[neornith,]
  cs.gator <- cs[gator.dev,]
  cs.chick <- cs[chick.dev,]
  cs.dino.dev <- cs[dino.dev,]
 
  tax.code <- rep(NA, dim(shape.data)[3])
  tax.code[c(gator.dev,dinos,dino.dev)] <- "na.arch"
  tax.code[c(chick.dev, neornith)] <- "birds"
  tax.code[19] <- "birds" # or remove from analysis
  
  tax.code.2 <- rep(NA, dim(shape.data)[3])
  tax.code.2[gator.dev] <- "alligator"
  tax.code.2[ornithiscian] <- "ornithischia"
  tax.code.2[saurischian] <- "saurischia"
  tax.code.2[c(chick.dev, neornith)] <- "birds"
  tax.code.2[19] <- "archaeopteryx" # or remove from analysis
 
  tax.dev.code <- rep(NA, dim(shape.data)[3])
  tax.dev.code[dinos] <- "dinos"
  tax.dev.code[neornith] <- "birds"
  tax.dev.code[gator.dev] <- "gator.dev"
  tax.dev.code[chick.dev] <- "chick.dev"
  tax.dev.code[dino.dev] <- "dino.dev"
  tax.dev.code[19] <- "archaeopteryx"
  
  tax.dev.code.2 <- rep(NA, dim(shape.data)[3])
  tax.dev.code.2[ornithiscian] <- "ornithischia"
  tax.dev.code.2[saurischian] <- "saurischia"
  tax.dev.code.2[neornith] <- "birds"
  tax.dev.code.2[gator.dev] <- "gator.dev"
  tax.dev.code.2[chick.dev] <- "chick.dev"
  tax.dev.code.2[ornithischia.dev] <- "ornithischia.dev"
  tax.dev.code.2[saurischia.dev] <- "saurischia.dev"
  tax.dev.code.2[19] <- "archaeopteryx"
  
  tax.dev.code.3 <- rep(NA, dim(shape.data)[3])
  tax.dev.code.3[ornithiscian] <- "ornithischia"
  tax.dev.code.3[saurischian] <- "saurischia"
  tax.dev.code.3[neornith] <- "birds"
  tax.dev.code.3[gator.dev] <- "gator.dev"
  tax.dev.code.3[chick.dev] <- "chick.dev"
  tax.dev.code.3[ornithischia.dev] <- "ornithischia"
  tax.dev.code.3[saurischia.dev] <- "saurischia"
  tax.dev.code.3[19] <- "archaeopteryx"
  
  tax.dev.code.4 <- rep(NA, dim(shape.data)[3])
  tax.dev.code.4[ornithiscian] <- "ornithischia"
  tax.dev.code.4[saurischian] <- "saurischia"
  tax.dev.code.4[neornith] <- "birds"
  tax.dev.code.4[gator.dev] <- "gator.dev"
  tax.dev.code.4[chick.dev] <- "chick.dev"
  tax.dev.code.4[ornithischia.dev] <- "ornithischia.juv"
  tax.dev.code.4[saurischia.dev] <- "saurischia.juv"
  tax.dev.code.4[psittaco] <- "psittaco"
  tax.dev.code.4[19] <- "archaeopteryx"
  
  dev.code <- rep("no.dev", dim(shape.data)[3])
  dev.code[c(chick.dev, gator.dev, dino.dev)] <- "dev"
  
  dev.code.2 <- rep("no.dev", dim(shape.data)[3])
  dev.code.2[c(chick.dev, gator.dev, psittaco)] <- "dev"
}

### << REGIONAL LANDMARK ASSIGNMENT >> ###
{
cerebrum <- 1:54
opticlobe <- 55:83
cerebellum <- 84:101
medulla <- 102:119
}

### << REGIONAL ALIGNMENT >> ###
{
cerebrum.shape <- gpagen(shape.data[cerebrum,,])$coords
opticlobe.shape <- gpagen(shape.data[opticlobe,,])$coords
cerebellum.shape <- gpagen(shape.data[cerebellum,,])$coords
medulla.shape <- gpagen(shape.data[medulla,,])$coords
# proportional regional centroid size
cerebrum.cs <- gpagen(shape.data[cerebrum,,])$Csize
opticlobe.cs <- gpagen(shape.data[opticlobe,,])$Csize
cerebellum.cs <- gpagen(shape.data[cerebellum,,])$Csize
medulla.cs <- gpagen(shape.data[medulla,,])$Csize
}

### << MORPHOSPACE >> ###
pca.shape <- prcomp(two.d.array(shape.data[,,]))
pc1.shape <- pca.shape$x[,1]
pc2.shape <- pca.shape$x[,2]
pc3.shape <- pca.shape$x[,3]
{
palette <- brewer.pal(n=4, name="Dark2")
mspace.palette <- c("white", palette[3], NA, NA,"#56B4E9", NA, NA, palette[2], NA)
mspace.ptshape <- c(5,21)
ptshape.palette <- c("black", "black", palette[3], palette[1], "black", "#56B4E9","#56B4E9", "black", palette[2]) 
ptsize <- c(4,4,4,4,4,4)
p <- ggplot(data=NULL, aes(x=pc1.shape, y=pc2.shape))
p <- p + geom_point(size=ptsize[factor(tax.dev.code)], shape=mspace.ptshape[factor(dev.code.2)], colour=ptshape.palette[factor(tax.dev.code.4)], fill=mspace.palette[factor(tax.dev.code.4)], stroke=2)
p <- p + xlab("PC1 (57.9%)") + ylab("PC2 (10.1%)")
#p <- p + xlim(-0.22, 0.4)
p <- p + geom_text(aes(label=labels, hjust=-0.1), size=3, colour="black")
p <- p + theme_bw() #+ coord_fixed(ratio=1) 
p <- p + theme(axis.title=element_text(size=18), axis.text=element_text(size=12), panel.border = element_blank(), panel.grid.major = element_line(colour="grey"), panel.grid.minor = element_line(colour="grey"), axis.line = element_line(colour = "black"), legend.title=element_blank()) + guides(size=guide_legend(override.aes=list(shape=21)))
p
}
pca.shape <- gm.prcomp(shape.data)
pc1max.shape <- pca.shape$shapes$shapes.comp1$max
pc1min.shape <- pca.shape$shapes$shapes.comp1$min
spheres3d(pc1max.shape, radius=0.006, color="grey")
spheres3d(pc1min.shape, radius=0.006, color="grey")
pc2max.shape <- pca.shape$shapes$shapes.comp2$max
pc2min.shape <- pca.shape$shapes$shapes.comp2$min
spheres3d(pc2max.shape, radius=0.006, color="grey")
spheres3d(pc2min.shape, radius=0.006, color="grey")


 ## < Cerebrum Shape > ##
pca.shape <- prcomp(two.d.array(cerebrum.shape[,,]))
pc1.shape <- pca.shape$x[,1]
pc2.shape <- pca.shape$x[,2]
pc3.shape <- pca.shape$x[,3]
{
  p <- ggplot(data=NULL, aes(x=pc1.shape, y=pc2.shape))
  p <- p + geom_point(size=ptsize[factor(tax.dev.code)], shape=mspace.ptshape[factor(dev.code.2)], colour=ptshape.palette[factor(tax.dev.code.4)], fill=mspace.palette[factor(tax.dev.code.4)], stroke=2)
  p <- p + xlab("PC1 (39.6%)") + ylab("PC2 (17.2%)")
  p <- p + xlim(-0.25, 0.4)
  p <- p + geom_text(aes(label=labels, hjust=-0.1), size=2, colour="black")
  p <- p + theme_bw() #+ coord_fixed(ratio=1) 
  p <- p + theme(axis.title=element_text(size=18), axis.text=element_text(size=12), panel.border = element_blank(), panel.grid.major = element_line(colour="grey"), panel.grid.minor = element_line(colour="grey"), axis.line = element_line(colour = "black"), legend.title=element_blank()) + guides(size=guide_legend(override.aes=list(shape=21)))
  p
}
pca.shape <- gm.prcomp(cerebrum.shape)
pc1max.shape <- pca.shape$shapes$shapes.comp1$max
pc1min.shape <- pca.shape$shapes$shapes.comp1$min
spheres3d(pc1max.shape, radius=0.015, color="grey")
spheres3d(pc1min.shape, radius=0.015, color="grey")
pc2max.shape <- pca.shape$shapes$shapes.comp2$max
pc2min.shape <- pca.shape$shapes$shapes.comp2$min
spheres3d(pc2max.shape, radius=0.015, color="grey")
spheres3d(pc2min.shape, radius=0.015, color="grey")

 ## < Optic Lobe Shape > ##
pca.shape <- prcomp(two.d.array(opticlobe.shape[,,]))
pc1.shape <- pca.shape$x[,1]
pc2.shape <- pca.shape$x[,2]
pc3.shape <- pca.shape$x[,3]
{
  p <- ggplot(data=NULL, aes(x=pc1.shape, y=pc2.shape))
  p <- p + geom_point(size=ptsize[factor(tax.dev.code)], shape=mspace.ptshape[factor(dev.code.2)], colour=ptshape.palette[factor(tax.dev.code.4)], fill=mspace.palette[factor(tax.dev.code.4)], stroke=2)
  p <- p + xlab("PC1 (37.6%)") + ylab("PC2 (24.7%)")
  #p <- p + xlim(-0.4, 0.3)
  #p <- p + geom_text(aes(label=labels, hjust=-0.1), size=2, colour="black")
  p <- p + theme_bw() #+ coord_fixed(ratio=1) 
  p <- p + theme(axis.title=element_text(size=18), axis.text=element_text(size=12), panel.border = element_blank(), panel.grid.major = element_line(colour="grey"), panel.grid.minor = element_line(colour="grey"), axis.line = element_line(colour = "black"), legend.title=element_blank()) + guides(size=guide_legend(override.aes=list(shape=21)))
  p
}

pca.shape <- gm.prcomp(opticlobe.shape)
pc1max.shape <- pca.shape$shapes$shapes.comp1$max
pc1min.shape <- pca.shape$shapes$shapes.comp1$min
spheres3d(pc1max.shape, radius=0.02, color="grey")
spheres3d(pc1min.shape, radius=0.02, color="grey")
pc2max.shape <- pca.shape$shapes$shapes.comp2$max
pc2min.shape <- pca.shape$shapes$shapes.comp2$min
spheres3d(pc2max.shape, radius=0.02, color="grey")
spheres3d(pc2min.shape, radius=0.02, color="grey")

## < Cerebellum Shape > ##
pca.shape <- prcomp(two.d.array(cerebellum.shape[,,]))
#pca.shape <- prcomp(two.d.array(shape.data[cerebrum,,]))
pc1.shape <- pca.shape$x[,1]
pc2.shape <- pca.shape$x[,2]
pc3.shape <- pca.shape$x[,3]
{
  p <- ggplot(data=NULL, aes(x=pc1.shape, y=pc2.shape))
  p <- p + geom_point(size=ptsize[factor(tax.dev.code)], shape=mspace.ptshape[factor(dev.code.2)], colour=ptshape.palette[factor(tax.dev.code.4)], fill=mspace.palette[factor(tax.dev.code.4)], stroke=2)
  p <- p + xlab("PC1 (42.7%)") + ylab("PC2 (18.8%)")
  p <- p + xlim(-0.42, 0.3)
  p <- p + geom_text(aes(label=labels, hjust=-0.1), size=2, colour="black")
  p <- p + theme_bw() #+ coord_fixed(ratio=1) 
  p <- p + theme(axis.title=element_text(size=18), axis.text=element_text(size=12), panel.border = element_blank(), panel.grid.major = element_line(colour="grey"), panel.grid.minor = element_line(colour="grey"), axis.line = element_line(colour = "black"), legend.title=element_blank()) + guides(size=guide_legend(override.aes=list(shape=21)))
  p
}
pca.shape <- gm.prcomp(cerebellum.shape)
pc1max.shape <- pca.shape$shapes$shapes.comp1$max
pc1min.shape <- pca.shape$shapes$shapes.comp1$min
spheres3d(pc1max.shape, radius=0.02, color="grey")
spheres3d(pc1min.shape, radius=0.02, color="grey")
pc2max.shape <- pca.shape$shapes$shapes.comp2$max
pc2min.shape <- pca.shape$shapes$shapes.comp2$min
spheres3d(pc2max.shape, radius=0.02, color="grey")
spheres3d(pc2min.shape, radius=0.02, color="grey")

## < Brainstem Shape > ##
pca.shape <- prcomp(two.d.array(medulla.shape[,,]))
pc1.shape <- pca.shape$x[,1]
pc2.shape <- pca.shape$x[,2]
pc3.shape <- pca.shape$x[,3]
{
  p <- ggplot(data=NULL, aes(x=pc1.shape, y=pc2.shape))
  p <- p + geom_point(size=ptsize[factor(tax.dev.code)], shape=mspace.ptshape[factor(dev.code.2)], colour=ptshape.palette[factor(tax.dev.code.4)], fill=mspace.palette[factor(tax.dev.code.4)], stroke=2)
  p <- p + xlab("PC1 (47.3%)") + ylab("PC2 (16.4%)")
  p <- p + xlim(-0.3, 0.4)
  p <- p + geom_text(aes(label=labels, hjust=-0.1), size=2, colour="black")
  p <- p + theme_bw() #+ coord_fixed(ratio=1) 
  p <- p + theme(axis.title=element_text(size=18), axis.text=element_text(size=12), panel.border = element_blank(), panel.grid.major = element_line(colour="grey"), panel.grid.minor = element_line(colour="grey"), axis.line = element_line(colour = "black"), legend.title=element_blank()) + guides(size=guide_legend(override.aes=list(shape=21)))
  p
}
pca.shape <- gm.prcomp(medulla.shape)
pc1max.shape <- pca.shape$shapes$shapes.comp1$max
pc1min.shape <- pca.shape$shapes$shapes.comp1$min
spheres3d(pc1max.shape, radius=0.02, color="grey")
spheres3d(pc1min.shape, radius=0.02, color="grey")
pc2max.shape <- pca.shape$shapes$shapes.comp2$max
pc2min.shape <- pca.shape$shapes$shapes.comp2$min
spheres3d(pc2max.shape, radius=0.02, color="grey")
spheres3d(pc2min.shape, radius=0.02, color="grey")

### << Allometric Trajectories Figures >> ##
 ## < Endocast > ##
cac <- CAC(shape.data, cs, log=TRUE)$CACscores
rsc1 <- CAC(shape.data, cs, log=TRUE)$RSCscores[,1]
{
  p <- ggplot(data=NULL, aes(x=cac, y=-rsc1))
  p <- p + geom_point(size=ptsize[factor(tax.dev.code)], shape=mspace.ptshape[factor(dev.code.2)], colour=ptshape.palette[factor(tax.dev.code.4)], fill=mspace.palette[factor(tax.dev.code.4)], stroke=2)
  p <- p + xlab("Common Allometric Component") + ylab("PC1 Residual Shape")
  #p <- p + xlim(-0.15, 0.3)
  #p <- p + ylim(-0.23, 0.2)
  #p <- p + geom_text(aes(label=labels, hjust=-0.1), size=2, colour="black")
  p <- p + theme_bw()
  p <- p + theme(axis.title=element_text(size=18), axis.text=element_text(size=12), panel.border = element_blank(), panel.grid.major = element_line(colour="grey"), panel.grid.minor = element_line(colour="grey"), axis.line = element_line(colour = "black"), legend.title=element_blank()) + guides(size=guide_legend(override.aes=list(shape=21)))
  p <- p + geom_smooth(method="lm", aes(group=tax.dev.code.3), fullrange=FALSE, show.legend=TRUE, color="black")
  p
}
 ## < Regional > ##
cac <- CAC(cerebellum.shape, cerebellum.cs, log=TRUE)$CACscores
rsc1 <- CAC(cerebellum.shape, cerebellum.cs, log=TRUE)$RSCscores[,1]
{
  p <- ggplot(data=NULL, aes(x=cac, y=-rsc1))
  p <- p + geom_point(size=ptsize[factor(tax.dev.code)], shape=mspace.ptshape[factor(dev.code.2)], colour=ptshape.palette[factor(tax.dev.code.4)], fill=mspace.palette[factor(tax.dev.code.4)], stroke=2)
  p <- p + xlab("Common Allometric Component") + ylab("PC1 Residual Shape")
  #p <- p + xlim(-0.25, 0.35)
  #p <- p + geom_text(aes(label=labels, hjust=-0.1), size=2, colour="black")
  p <- p + theme_bw()
  p <- p + theme(aspect.ratio=1, axis.title=element_text(size=18), axis.text=element_text(size=12), panel.border = element_blank(), panel.grid.major = element_line(colour="grey"), panel.grid.minor = element_line(colour="grey"), axis.line = element_line(colour = "black"), legend.title=element_blank()) + guides(size=guide_legend(override.aes=list(shape=21)))
  p
}

### << SHAPE DIFFERENCE BETWEEN DINOS AND BIRDS >> ###
y <- shape.nodev[,,-3]  # remove alligator
x <- tax.code[no.dev]
x <- x[-1]
summary(procD.lm(y~x))
summary(procD.pgls(y~x, phy=drop.tip(phy, tip="Alligator_Adult_endocast")))

### << TESTS FOR DIFFERENCES IN ALLOMETRIC SIGNAL >> ###
 ## Dinosaurs vs. Birds ##
 dino.bird.allom <- procD.pgls(shape.nodev ~ log(cs.no.dev) + tax.code[no.dev], phy=phy, iter=9999)
 summary(dino.bird.allom)
 
 ## Psittaco vs. Chicken Dev ##
 y <- shape.data[,,c(psittaco,chick.dev)]
 x.1 <- log.cs[(c(psittaco,chick.dev)),]
 x.2 <- c("psittaco", "psittaco", "psittaco", "psittaco","chick.dev","chick.dev","chick.dev","chick.dev","chick.dev","chick.dev","chick.dev","chick.dev","chick.dev","chick.dev","chick.dev","chick.dev","chick.dev","chick.dev")
 dino.chick.allom <- procD.lm(y ~ x.1 + x.2, iter=9999)
 summary(dino.chick.allom)
 
 fit <- procD.lm(y~x.1 + x.2, iter=9999)
 pw.psitt.chick <- pairwise(fit, groups=x.2)
 summary(pw.psitt.chick, confidence=0.95, test.type="dist")
 summary(pw.psitt.chick, confidence=0.95, test.type="DL")
 summary(pw.psitt.chick, confidence=0.95, test.type="VC", angle.type="deg")
 
 ## Psittaco vs. Alligator Dev ##
 y <- shape.data[,,c(psittaco,gator.dev)]
 x.1 <- log.cs[(c(psittaco,gator.dev)),]
 x.2 <- c("psittaco", "psittaco", "psittaco", "psittaco","gator.dev","gator.dev","gator.dev","gator.dev","gator.dev","gator.dev","gator.dev","gator.dev","gator.dev","gator.dev","gator.dev","gator.dev","gator.dev","gator.dev")
 dino.gator.allom <- procD.lm(y ~ x.1 + x.2, iter=9999)
 summary(dino.gator.allom)
 
 fit <- procD.lm(y~x.1 + x.2, iter=9999)
 pw.psitt.gator <- pairwise(fit, groups=x.2)
 summary(pw.psitt.gator, confidence=0.95, test.type="dist")
 summary(pw.psitt.gator, confidence=0.95, test.type="DL")
 summary(pw.psitt.gator, confidence=0.95, test.type="VC", angle.type="deg")
 
 ## Alligator vs. Chicken Dev ##
 y <- shape.data[,,c(gator.dev, chick.dev)]
 x.1 <- log.cs[(c(gator.dev, chick.dev)),]
 x.2 <- tax.dev.code[c(gator.dev, chick.dev)]
 chick.gator.allom <- procD.lm(y ~ x.1 + x.2, iter=9999)
 summary(chick.gator.allom)

 fit <- procD.lm(y~x.1 + x.2, iter=9999)
 pw.gator.chick <- pairwise(fit, groups=x.2)
 summary(pw.gator.chick, confidence=0.95, test.type="dist")
 summary(pw.gator.chick, confidence=0.95, test.type="DL")
 summary(pw.gator.chick, confidence=0.95, test.type="VC", angle.type="deg")
 
### << ALLOMETRY >> ###
 cerebrum.cs.nodev <- cerebrum.cs[no.dev]
 opticlobe.cs.nodev <- opticlobe.cs[no.dev]
 cerebellum.cs.nodev <- cerebellum.cs[no.dev]
 medulla.cs.nodev <- medulla.cs[no.dev]
  
 ## Archosaur ##
 {
 shape.nodev <- shape.data[,,no.dev]
 cs.no.dev <- cs[no.dev,]
 allom <- procD.lm(shape.nodev~log(cs.no.dev))
 ev.allom <- procD.pgls(shape.nodev~log(cs.no.dev), phy)
 }
 ## Non-Avian Dinosaurs ##
 shape.dino <- shape.data[,,dinos]
 cs.dino <- cs[dinos,]
 allom.dino <- procD.lm(shape.dino~log(cs.dino))
 ev.allom.dino <- procD.pgls(shape.dino~log(cs.dino), drop.tip(phy, labels[-dinos]))
  # Region (Globally Aligned) #
  physig.dino <- physignal(shape.dino[medulla,,], drop.tip(phy, labels[-dinos]))
  allom.dino <- procD.lm(shape.dino[medulla,,]~log(cs.dino))
  ev.allom.dino <- procD.pgls(shape.dino[medulla,,]~log(cs.dino), drop.tip(phy, labels[-dinos]))
  # Region (Locally Aligned) #
  medulla.dino <- medulla.shape[,,dinos]
  medulla.cs.dino <- medulla.cs[dinos,]
  physig.dino <- physignal(medulla.dino, drop.tip(phy, labels[-dinos]))
  allom.dino <- procD.lm(medulla.dino~log(medulla.cs.dino))
  ev.allom.dino <- procD.pgls(medulla.dino~log(medulla.cs.dino), drop.tip(phy, labels[-dinos]))
 
 ## Neornithes ##
 shape.neornith <- shape.data[,,neornith]
 cs.neornith <- cs[neornith,]
 allom.neornith <- procD.lm(shape.neornith~log(cs.neornith))
 physig.neornith <- physignal(shape.neornith, drop.tip(phy, labels[-neornith]))
 ev.allom.neornith <- procD.pgls(shape.neornith~log(cs.neornith), drop.tip(phy, labels[-neornith]))
  # Region (Globally Aligned) #
  medulla.cs.neornith <- medulla.cs[neornith]
  physig.neornith <- physignal(shape.neornith[medulla,,], drop.tip(phy, labels[-neornith]))
  allom.neornith <- procD.lm(shape.neornith[medulla,,]~log(cs.neornith))
  ev.allom.neornith <- procD.pgls(shape.neornith[medulla,,]~log(cs.neornith), drop.tip(phy, labels[-neornith]))
  # Region (Locally Aligned) #
  medulla.neornith <- medulla.shape[,,neornith]
  physig.neornith <- physignal(medulla.neornith, drop.tip(phy, labels[-neornith]))
  allom.neornith <- procD.lm(medulla.neornith~log(medulla.cs.neornith))
  ev.allom.neornith <- procD.pgls(medulla.neornith~log(medulla.cs.neornith), drop.tip(phy, labels[-neornith]))
  
 ## Cerebrum ##
 allom.cerebrum <- procD.lm(shape.nodev[cerebrum,,]~log(cs.no.dev))
 physig.cerebrum <- physignal(shape.nodev[cerebrum,,], phy)
 ev.allom.cerebrum <- procD.pgls(shape.nodev[cerebrum,,]~log(cs.no.dev), phy)
 
 allom.cerebrum <- procD.lm(cerebrum.shape[,,no.dev]~log(cerebrum.cs.nodev))
 physig.cerebrum <- physignal(cerebrum.shape[,,no.dev], phy)
 ev.allom.cerebrum <- procD.pgls(cerebrum.shape[,,no.dev]~log(cerebrum.cs.nodev), phy)
 
 ## Optic Lobe ##
 allom.opticlobe <- procD.lm(shape.nodev[opticlobe,,]~log(cs.no.dev))
 physig.opticlobe <- physignal(shape.nodev[opticlobe,,], phy)
 ev.allom.opticlobe <- procD.pgls(shape.nodev[opticlobe,,]~log(cs.no.dev), phy)
 
 allom.opticlobe <- procD.lm(opticlobe.shape[,,no.dev]~log(opticlobe.cs.nodev))
 physig.opticlobe <- physignal(opticlobe.shape[,,no.dev], phy)
 ev.allom.opticlobe <- procD.pgls(opticlobe.shape[,,no.dev]~log(opticlobe.cs.nodev), phy)

 ## Cerebellum ##
 allom.cerebellum <- procD.lm(shape.nodev[cerebellum,,]~log(cs.no.dev))
 physig.cerebellum <- physignal(shape.nodev[cerebellum,,], phy)
 ev.allom.cerebellum <- procD.pgls(shape.nodev[cerebellum,,]~log(cs.no.dev), phy)
 
 allom.cerebellum <- procD.lm(cerebellum.shape[,,no.dev]~log(cerebellum.cs.nodev))
 physig.cerebellum <- physignal(cerebellum.shape[,,no.dev], phy)
 ev.allom.cerebellum <- procD.pgls(cerebellum.shape[,,no.dev]~log(cerebellum.cs.nodev), phy)

 ## Brainstem ##
 allom.medulla <- procD.lm(shape.nodev[medulla,,]~log(cs.no.dev))
 physig.medulla <- physignal(shape.nodev[medulla,,], phy)
 ev.allom.medulla <- procD.pgls(shape.nodev[medulla,,]~log(cs.no.dev), phy)
 
 allom.medulla <- procD.lm(medulla.shape[,,no.dev]~log(medulla.cs.nodev))
 physig.medulla <- physignal(medulla.shape[,,no.dev], phy)
 ev.allom.medulla <- procD.pgls(medulla.shape[,,no.dev]~log(medulla.cs.nodev), phy)

 ## Alligator Development ##
 summary(procD.lm(shape.gator~log(cs.gator)))
 summary(procD.lm(shape.gator[cerebrum,,]~log(cs.gator)))
 summary(procD.lm(shape.gator[opticlobe,,]~log(cs.gator)))
 summary(procD.lm(shape.gator[cerebellum,,]~log(cs.gator)))
 summary(procD.lm(shape.gator[medulla,,]~log(cs.gator)))
 
 cerebrum.gator <- cerebrum.shape[,,gator.dev]
 summary(procD.lm(cerebrum.gator~log(cs.gator)))
 opticlobe.gator <- opticlobe.shape[,,gator.dev]
 summary(procD.lm(opticlobe.gator~log(cs.gator)))
 cerebellum.gator <- cerebellum.shape[,,gator.dev]
 summary(procD.lm(cerebellum.gator~log(cs.gator)))
 medulla.gator <- medulla.shape[,,gator.dev]
 summary(procD.lm(medulla.gator~log(cs.gator)))
 
 ## Chicken Development ##
 summary(procD.lm(shape.chick~log(cs.chick)))
 summary(procD.lm(shape.chick[cerebrum,,]~log(cs.chick)))
 summary(procD.lm(shape.chick[opticlobe,,]~log(cs.chick)))
 summary(procD.lm(shape.chick[cerebellum,,]~log(cs.chick)))
 summary(procD.lm(shape.chick[medulla,,]~log(cs.chick)))
 
 cerebrum.chick <- cerebrum.shape[,,chick.dev]
 summary(procD.lm(cerebrum.chick~log(cs.chick)))
 opticlobe.chick <- opticlobe.shape[,,chick.dev]
 summary(procD.lm(opticlobe.chick~log(cs.chick)))
 cerebellum.chick <- cerebellum.shape[,,chick.dev]
 summary(procD.lm(cerebellum.chick~log(cs.chick)))
 medulla.chick <- medulla.shape[,,chick.dev]
 summary(procD.lm(medulla.chick~log(cs.chick)))
 
##  Allometric Trajectories Figures ##
 palette <- brewer.pal(n=3, name="Dark2")
 mspace.palette <- c("white", palette[3], NA, palette[2], NA)
 regr.palette <- c(NA,palette[3],palette[3],palette[2],palette[1])
 mspace.ptshape <- c(5,21)
 ptshape.palette <- c("black", "black", palette[3], "black", palette[1]) 
 ptsize <- c(6,6,4,6,4)
 # Endocast #
cac <- CAC(shape.data, cs, log=TRUE)$CACscores
rsc1 <- CAC(shape.data, cs, log=TRUE)$RSCscores[,1]
{
  p <- ggplot(data=NULL, aes(x=cac, y=-rsc1))
  p <- p + geom_point(size=ptsize[factor(tax.dev.code)], shape=mspace.ptshape[factor(dev.code)], colour=ptshape.palette[factor(tax.dev.code)], fill=mspace.palette[factor(tax.dev.code)], stroke=2)
  p <- p + xlab("Common Allometric Component") + ylab("PC1 Residual Shape")
  #p <- p + xlim(-0.3, 0.5) + ylim(-0.2, 0.2)
  p <- p + geom_text(aes(label=labels, hjust=-0.1), size=3, colour="black")
  p <- p + theme_bw()
  p <- p + theme(axis.title=element_text(size=18), axis.text=element_text(size=12), panel.border = element_blank(), panel.grid.major = element_line(colour="grey"), panel.grid.minor = element_line(colour="grey"), axis.line = element_line(colour = "black"), legend.title=element_blank()) + guides(size=guide_legend(override.aes=list(shape=21)))
  p <- p + geom_smooth(method="lm", aes(group=tax.dev.code), fullrange=FALSE, show.legend=TRUE, color="black")
  p
}

 # Regional #
cac <- CAC(opticlobe.shape, opticlobe.cs, log=TRUE)$CACscores
rsc1 <- CAC(opticlobe.shape, opticlobe.cs, log=TRUE)$RSCscores[,1]
{
  p <- ggplot(data=NULL, aes(x=cac, y=-rsc1))
  p <- p + geom_point(size=ptsize[factor(tax.dev.code)], shape=mspace.ptshape[factor(dev.code)], colour=ptshape.palette[factor(tax.dev.code)], fill=mspace.palette[factor(tax.dev.code)], stroke=2)
  p <- p + xlab("Common Allometric Component") + ylab("PC1 Residual Shape")
  #p <- p + xlim(-0.35, 0.35) + ylim(-0.15, 0.35)
  #p <- p + geom_text(aes(label=labels, hjust=-0.1), size=3, colour="black")
  p <- p + theme_bw()
  p <- p + theme(aspect.ratio=1, axis.title=element_text(size=18), axis.text=element_text(size=12), panel.border = element_blank(), panel.grid.major = element_line(colour="grey"), panel.grid.minor = element_line(colour="grey"), axis.line = element_line(colour = "black"), legend.title=element_blank()) + guides(size=guide_legend(override.aes=list(shape=21)))
  p
}
 
### FIGURE 1. PHYLOGENETIC TREE ###
phy$root.time <- phy$edge.length[1]
 geoscalePhylo(phy, direction="rightwards", units=c("Period", "Epoch"), label.offset=1, cex.age=0.8, cex.ts=0.8, cex.tip=0.8)
 
### FIGURE 2. Mesh Images with Landmarks ##
# opened the mesh in meshlab and did Filters --> Color Creation and Processing --> Ambient Occlusion per Vertex
 mesh <- vcgImport("./ply/IVPP 15451 - 1 year old_decimated.ply", readcolor = TRUE)
 sp.coord <- coord.data[left.lm,,6]
 left.lm.list <- 1:119
 fixed.lm <- c(1,47,54,55,78,83,84,86,99,101,102,104,117,119)
 curve.lm <- sort(c(48:53,46,39,32,25,17,9,2,10,18,56:59,60,65,72,82,65,71,77,85,89,92,95,98,87,90,93,96,100,103,105,108,111,114,118,116,113,110,107))
 surface.list <- left.lm.list[! left.lm.list %in% unlist(curve.lm)] # removes LMs and curve semi-LMs
 {
 shade3d(mesh, color="white") #note that you dont specify a color anymore
 spheres3d(sp.coord[fixed.lm,], color="red", radius=0.3)
 spheres3d(sp.coord[curve.lm,], color="gold", radius=0.2)
 spheres3d(sp.coord[c(surface.list,109,112),], color="blue", radius=0.1)
 }
 snapshot3d(filename="/Users/watanabe/Desktop/TheropodPLUS_LandmarkScheme.png")
 
 ### CONVERGENCE OF NON-AVIALAN DINOS TO ADULT ALLIGATOR ###
 gator.adult <- shape.data[,,3]
 #cs.order <- order(cs[dinos])
 dist.list <- NULL
 for(i in 1:dim(shape.dinos)[3]) {
   dino.shape <- shape.dinos[,,i]
   comb.shape <- abind(gator.adult, dino.shape, along=3)
   two.d.comb.shape <- two.d.array(comb.shape)
   proc.dist <- dist(two.d.comb.shape)
   dist.list[i] <- proc.dist
 }
  ## plot ##
plot(cs[dinos], dist.list, ylab="Procrustes distance", xlab="Centroid size")
dist.cs.dinos <- lm(dist.list~cs[dinos])
summary(dist.cs.dinos) 
 